using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ConverterScript : MonoBehaviour
{
    public InputField inputAmount;
    public InputField inputConvertedAmount;

    public Toggle toggleUSDollar;
    public Toggle toggleJPNYen;
    public Toggle toggleRM;
    public Toggle toggleEUR;
    public Toggle toggleKRW;
    public Toggle toggleTWD;

    public Text debugtext;

    

    private const float SGDUSD = 0.74f;
    private const float SGDJPY = 82.78f;
    private const float SGDRM = 3.08f;
    private const float SGDEUR = 0.63f;
    private const float SGDKRW = 881.54f;
    private const float SGDTWD = 20.73f;



    private float userInputAmount;


    // Start is called before the first frame update
    void Start()
    {
        ClearPressed();
    }



    public void ConvertPressed()
    {
        debugtext.text = "";

        if (!ValidAmount(inputAmount.text))
        {
            debugtext.text = "Please enter a valid amount.";
            return;
        }

        if (ToggleCount() > 1)
        {
            debugtext.text = "Please select only one currency";
        }

        if (ToggleCount() == 0)
        {
            debugtext.text = "Please select one currency";
        }


        if (!UserInputCheck() && ToggleCount() == 1)
        {

        if (toggleUSDollar.isOn == true)
        {
            inputConvertedAmount.text = "$" + (userInputAmount * SGDUSD);
        }
        else if (toggleJPNYen.isOn == true)
        {
            inputConvertedAmount.text = "$" + (userInputAmount * SGDJPY);
        }
        else if(toggleRM.isOn == true)
        {
            inputConvertedAmount.text = "$" + (userInputAmount * SGDRM);
        }
        else if (toggleEUR.isOn == true)
        {
            inputConvertedAmount.text = "$" + (userInputAmount * SGDEUR);
        }
        else if (toggleKRW.isOn == true)
        {
            inputConvertedAmount.text = "$" + (userInputAmount * SGDKRW);
        }
        else if (toggleTWD.isOn == true)
        {
            inputConvertedAmount.text = "$" + (userInputAmount * SGDTWD);
        }

        }
    }

    private bool ValidAmount(string textInput)
    {
        try
        {
            userInputAmount = float.Parse(textInput);
            return true;
        }
        catch (Exception e)
        {
            debugtext.text = "Error: " + e;
            return false;
        }
    }

    public void ClearPressed()
    {
        toggleUSDollar.isOn = false;
        toggleJPNYen.isOn = false;


        inputAmount.text = "";
        inputConvertedAmount.text = "";

        debugtext.text = "";
    }

    private bool UserInputCheck()
    {
        if (inputAmount.text.Length == 0)
        {
            debugtext.text = "Please input an amount to be converted.";
            return true;
        }
        else
        {
            return false;
        }
    }

    private int ToggleCount()
    {
        int Textcount = 0;

        if(toggleUSDollar.isOn)
        {
            Textcount++;
        }
        if (toggleJPNYen.isOn)
        {
            Textcount++;
        }
        if (toggleRM.isOn)
        {
            Textcount++;
        }
        if (toggleEUR.isOn)
        {
            Textcount++;
        }
        if (toggleKRW.isOn)
        {
            Textcount++;
        }
        if (toggleTWD.isOn)
        {
            Textcount++;
        }


        return Textcount;
    }

}
